import {readFile} from 'node:fs/promises';
import {multiplayerContract,gameType} from './bundle-rules.mjs';
const targets={
 mobile:'Build for a portrait phone viewport. Use touch-first controls, mobile safe areas, and never require a keyboard or mouse.',
 desktop:'Build for a responsive desktop viewport. Use keyboard and mouse controls and make the complete playfield fit without clipping.',
 'cross-platform':'Build one responsive game for phone and desktop. Provide equivalent touch controls and keyboard/mouse controls over one shared game state.',
};
const index=target=>'<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="slop-runtime" content="creator-v1"><meta name="slop-target" content="'+target+'"><title>Pocket Bounce</title></head><body><script src="slop.js"></script><script src="game.js"></script></body></html>';
const game=`const surface=Slop.create({background:'#faf3e8'}),ctx=surface.ctx;
let points=0,finished=false,announced=false,keyHeld=false;
Slop.onRestart(()=>{points=0;finished=false;keyHeld=false;Slop.score(0);});
Slop.loop(({time,width,height})=>{
 const keyDown=Slop.input.keys.has('Space')||Slop.input.keys.has('Enter');
 if((Slop.input.pressed||keyDown&&!keyHeld)&&!finished){points++;Slop.score(points);Slop.haptic('light');}
 keyHeld=keyDown;
 ctx.fillStyle='#faf3e8';ctx.fillRect(0,0,width,height);
 ctx.fillStyle='#302a3d';ctx.textAlign='center';ctx.font='bold 44px system-ui';ctx.fillText(points,width/2,height*.16);
 const y=height*.56-Math.abs(Math.sin(time*2.4))*36;
 ctx.fillStyle='#faaa47';ctx.beginPath();ctx.arc(width/2,y,48,0,Math.PI*2);ctx.fill();
 if(!points){ctx.fillStyle='#302a3d';ctx.font='bold 18px system-ui';ctx.fillText('Tap to bounce',width/2,height*.80);}
 if(!announced){announced=true;Slop.ready();}
 if(points>=10&&!finished){finished=true;Slop.finished(points);}
});`;
async function arcadeTemplate({target_platform='cross-platform'}={}){if(!Object.hasOwn(targets,target_platform))throw new Error('Choose mobile, desktop, or cross-platform.');const instructions=`Start from these files. ${targets[target_platform]} Keep slop.js unchanged and include both meta tags. Call Slop.ready only after the first usable rendered frame, Slop.score during play, and Slop.finished once at real game over. Use Slop.onRestart, Slop.loop and Slop.input so native/web pause, resume, pointer, keyboard and touch controls work. Render changing gameplay on a canvas so Slop can record real gameplay frames directly as a 30 fps H.264 MP4: 720×1280 portrait or 1280×720 landscape, plus a poster. Never convert a GIF into the feed video; GIFs are legacy compatibility only. Feed framing and HUD: preserve the full canvas with adaptive contain fitting across screen shapes, never crop gameplay or controls. Keep the player, targets and HUD inside the centered ~80% of the width and frame the camera/playfield slightly wide rather than tight. HUD = one big score or number near top-center plus at most 1-2 small icons (lives, a thin progress bar); no sentences, no \"SCORE:\"/\"LEVEL:\" labels, no stat panels in the corners. A control hint is at most 4 words and disappears on the first input; in-game callouts (combo, +10, PERFECT) are 1-2 words and fade quickly. Keep drafts private unless the owner explicitly submits for review or enables Auto-publish for this connection; publication still requires accepted recorded video. Sandbox rules: the game runs in an opaque-origin sandbox, so localStorage/sessionStorage/indexedDB throw and network requests are blocked; ship every file in the bundle (file names: letters, digits, _ or -, one html/js/css/json/svg/txt extension). The only external library is three.js r128 via Slop.three(); for 3D call Slop.create({renderer:'3d'}), render into surface.canvas with new THREE.WebGLRenderer({canvas:surface.canvas,preserveDrawingBuffer:true}) or recorded video and poster capture come back black. Slop captures the largest canvas, so keep one on-screen canvas that visibly moves even before input. Slop owns the start screen, pause and game-over card: do not draw a title, tap-to-start or play-again screen; at game over call Slop.finished once and keep animating until Slop.onRestart. slop.js calls preventDefault on pointerdown, so use pointer events, not mousedown or mouseup. On desktop, preventDefault wheel events so the page does not scroll, and give pointer lock a fallback. Slop.haptic is limited to 8 per second. Run slop_check_bundle before slop_send_draft.`;return {runtime:'creator-v1',target_platform,instructions,files:{'index.html':index(target_platform),'slop.js':await readFile(new URL('./runtime/creator-v1.js',import.meta.url),'utf8'),'slop-platform.json':JSON.stringify({target_platform}),'game.js':game}};}

const persistentGame=`async function boot(){
 const save=await Slop.persist({
  version:1,
  run:{floor:1,steps:0,__label:'Floor 1'},
  profile:{bestFloor:1,totalSteps:0},
  migrate(old,fromVersion,scope){return old;}
 });
 const surface=Slop.create({background:'#0c120d'}),ctx=surface.ctx;
 let finished=false,announced=false,keyHeld=false;
 Slop.onRestart(()=>{finished=false;keyHeld=false;Slop.score(0);});
 Slop.loop(({time,width,height})=>{
  const keyDown=Slop.input.keys.has('Space')||Slop.input.keys.has('Enter');
  if(!finished&&(Slop.input.pressed||keyDown&&!keyHeld)){
   save.run.steps++;save.profile.totalSteps++;save.commit();
   if(save.run.steps%5===0){
    save.run.floor++;save.run.__label='Floor '+save.run.floor;
    save.profile.bestFloor=Math.max(save.profile.bestFloor,save.run.floor);
    save.checkpoint(save.run.__label);
   }
   Slop.score(save.run.floor);
   if(save.run.floor>=5){finished=true;Slop.finished(save.run.floor);}
  }
  keyHeld=keyDown;
  ctx.fillStyle='#0c120d';ctx.fillRect(0,0,width,height);
  ctx.fillStyle='#c6ff5e';ctx.font='bold 40px system-ui';ctx.textAlign='center';
  ctx.fillText(save.run.floor,width/2,height*.16);
  ctx.beginPath();ctx.arc(width/2,height*.56-Math.abs(Math.sin(time*2))*25,38,0,Math.PI*2);ctx.fill();
  if(!announced){announced=true;Slop.ready();}
 });
}
boot().catch(error=>{console.error('Slop World could not open',error);});`;
export async function gameTemplate({game_type,target_platform='cross-platform',persistent=false,multiplayer}={}){
 gameType(game_type);
 if(multiplayer!==undefined&&multiplayer!==(game_type==='multiplayer'))throw new Error('game_type_mismatch');
 multiplayer=game_type==='multiplayer';
 if(persistent&&multiplayer)throw new Error('Slop Worlds and turn-based matches are separate game modes.');
 const template=await arcadeTemplate({target_platform});
 const baseInstructions=template.instructions;
 template.game_type=game_type;
 template.files['slop.spec.json']=JSON.stringify({game_type,multiplayer:false});
 template.instructions=`Game type: single-player. Build for one human, including any CPU opponents. This type cannot enter an online room or use Slop.match. A World is still single-player. Keep game_type in slop.spec.json and pass the same game_type to slop_check_bundle, slop_send_draft and slop_publish. ${template.instructions}`;
 if(multiplayer){
  const contract=multiplayerContract({protocol:'turns-v1',mode:'match',seats:2,max_turns:20,action_schema:{choice:{type:'enum',values:['left','right']}}});
  return {game_type,runtime:'multiplayer-v1',target_platform,multiplayer:contract,
   instructions:`Game type: multiplayer. Build online turn-based play for two authenticated humans using turns-v1, not a CPU-only game, local hot-seat, or real-time networking. Keep game_type in slop.spec.json and pass the same game_type to slop_check_bundle, slop_send_draft and slop_publish. ${baseInstructions}\nUse the unchanged multiplayer-v1 runtime and slop.spec.json multiplayer contract. Multiplayer belongs in Slop's Multiplayer tab. Slop.match.active distinguishes a live assigned room from solo preview/recording. Slop.match.snapshot() returns null until the authenticated host supplies a snapshot; subscribe(callback) returns an unsubscribe function. Wait for that snapshot before live input. Rebuild deterministic gameplay from snapshot.seed and the ordered actions on reconnect. Snapshot fields include room, seat, epoch, revision, status, turn, players, actions[{revision,seat,actionId,action}], releaseDigest and rematchVotes. Submit only your turn with await Slop.match.submit({actionId,expectedRevision:snapshot.revision,epoch:snapshot.epoch,action}); use a stable unique actionId for retries. The host owns authentication, room selection and transport. Never send user IDs, room IDs or opponent seats. The service validates action_schema, turn order, epoch and revision and stores the ordered action log; game physics and scoring remain deterministic client logic, not trusted server adjudication. max_turns bounds every round; there are no monetary rewards. await Slop.match.rematch() votes; both players must consent before a new epoch. Ignore old epoch/revision snapshots and reconstruct on rejoin. Render smoothly between accepted turns, never stream per-frame input. Provide clearly labeled practice for standalone previews and video recording; practice must never replace a live opponent or submit to a live room. Do not add your own lobby, start or result screen. No authored network or storage. Multiplayer needs the corresponding deployed host and match authority; local validation is not proof of live rollout.`,
   files:{...template.files,'index.html':index(target_platform).replace('creator-v1','multiplayer-v1'),
    'slop.js':await readFile(new URL('./runtime/multiplayer-v1.js',import.meta.url),'utf8'),
    'slop.spec.json':JSON.stringify({game_type,multiplayer:contract}),
    'game.js':multiplayerGame}};
 }
 if(!persistent)return template;
 const runtime='persistent-v1';
 return {
  game_type,runtime,target_platform,persistent:true,
  instructions:`Game type: single-player. Build a Slop World with durable run and profile progress for one human. Keep game_type in slop.spec.json and pass the same type to check, send and publish. Slop.match and online multiplayer are unavailable in a World. ${targets[target_platform]}
Keep slop.js unchanged and the slop-runtime persistent-v1 marker. Await Slop.persist({version,run,profile,migrate(old,fromVersion,scope)}) BEFORE Slop.ready and before gameplay starts. save.run and save.profile are live plain JSON objects; call save.commit after meaningful changes and save.checkpoint(label) at rooms/floors. Set save.run.__label for the platform Continue sheet. Do not draw a Continue, start or New run menu: Slop owns these. Slop.persist.newRun() is asynchronous; await it when your authored logic genuinely resets a run. Normal platform restart already clears run before Slop.onRestart; profile stays. Slop.finished(score) ends a genuine run and preserves profile. It is still a client-authored score, not proof of a reward.
Use Slop.create, Slop.loop(frame), Slop.input, Slop.onRestart and one real canvas. Call Slop.ready after the first usable rendered frame. Provide equivalent controls for the selected target, keep a terse centered HUD inside ~80% width, and preserve full gameplay with contain fitting. Capture a genuine moving H.264 MP4 plus poster, never synthetic gameplay.
Declare slop.spec.json persistent:true and first_load:[relative paths]. Include index.html, slop.js, game.js and every static HTML/CSS/module dependency needed before the first frame. Limits are decimal: 50,000,000 decoded bytes total, 8,000,000 per file, 400 files including metadata, and 5,000,000 first load. Arcade limits stay unchanged. run <=262,144 UTF-8 JSON bytes; profile <=131,072.
Text files stay strings. Binary .glb/.bin/.jpg/.webp/.ktx2/.ogg files use {encoding:'base64',data:'canonical base64'}; bytes and hashes are decoded bytes, not base64 length. Lazy load later zones with await Slop.asset('zones/forge.glb') -> {url,arrayBuffer()}; the host serves only verified files in this immutable release. Assets requested before ready must appear in first_load. Never fetch external URLs or use localStorage/sessionStorage/indexedDB. For 3D use await Slop.three() and await Slop.loadGLTF('model.glb'), self-contained GLB only; external GLTF resources and unsupported compressed decoders are rejected. KTX2 can be retrieved as bytes, not an advertised GLTF decoder. Set preserveDrawingBuffer:true for real captures.
Save commits are acknowledged after durable device storage; cloud sync is separate and may be offline. In-app closes await a flush; a browser/OS hard kill can only retain the most recent durable checkpoint, never promise zero loss from an unacknowledged write. Check slop_check_bundle before slop_send_draft. Keep drafts private until owner-approved publication. Worlds require deployed compatible host/authority; local template validation does not prove that rollout is live.`,
  files:{'index.html':index(target_platform).replace('creator-v1',runtime).replace('Pocket Bounce','Pocket World'),
   'slop.js':await readFile(new URL('./runtime/persistent-v1.js',import.meta.url),'utf8'),
   'slop-platform.json':JSON.stringify({target_platform}),
   'slop.spec.json':JSON.stringify({game_type,multiplayer:false,persistent:true,first_load:['index.html','slop.js','game.js','slop-platform.json']}),
   'game.js':persistentGame}
 };
}

const multiplayerGame=`const surface=Slop.create({background:'#faf3e8'}),ctx=surface.ctx;
let snapshot=null,points=0,finished=false,announced=false,pending=false,keyHeld=false;
Slop.match.subscribe(value=>{snapshot=value;points=value.actions.length;Slop.score(points);});
Slop.onRestart(()=>{finished=false;keyHeld=false;points=0;Slop.score(0);});
Slop.loop(({time,width,height})=>{
 const key=Slop.input.keys.has('Space')||Slop.input.keys.has('Enter');
 if((Slop.input.pressed||key&&!keyHeld)&&!pending&&!finished){
  if(Slop.match.active){
   if(snapshot&&snapshot.status==='active'&&snapshot.turn===snapshot.seat){
    pending=true;Slop.match.submit({actionId:'turn-'+snapshot.epoch+'-'+snapshot.revision,expectedRevision:snapshot.revision,epoch:snapshot.epoch,action:{choice:Slop.input.x<width/2?'left':'right'}}).catch(()=>{}).finally(()=>{pending=false;});
   }
  }else{points++;Slop.score(points);}
 }
 keyHeld=key;
 ctx.fillStyle='#faf3e8';ctx.fillRect(0,0,width,height);ctx.fillStyle='#302a3d';ctx.textAlign='center';ctx.font='bold 44px system-ui';ctx.fillText(points,width/2,height*.16);
 if(!Slop.match.active){ctx.font='14px system-ui';ctx.fillText('Practice',width/2,height*.24);}
 ctx.fillStyle='#faaa47';ctx.beginPath();ctx.arc(width/2,height*.56-Math.abs(Math.sin(time*2.4))*36,48,0,Math.PI*2);ctx.fill();
 if(!announced){announced=true;Slop.ready();}
 if(!finished&&(snapshot?.status==='complete'||!Slop.match.active&&points>=10)){finished=true;Slop.finished(points);}
});`;
