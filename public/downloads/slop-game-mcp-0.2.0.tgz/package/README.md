# Slop MCP

Build a little mobile game with your coding agent, then playtest it in Slop on
your phone or at [slop.game](https://slop.game/#/connect). The local MCP adapter
connects to Slop's deployed account and private-game services. You approve the
computer once, and review each draft revision before it becomes playable.

Connections can send private drafts and read their delivery status. They cannot
publish games, spend coins, buy assets, or change your account. Your agent never
receives your Slop password, account session, or private preview URL.

## Connect your coding agent

Install Node.js 22.12 or later. The versioned package is hosted by Slop; there is
no npm registry package to guess. It contains only the local adapter and its
pinned runtime dependencies are resolved by npm.

### Codex

Run in your computer's terminal:

```sh
codex mcp add slop -- npx --yes --package=https://slop.game/downloads/slop-game-mcp-0.2.0.tgz slop-mcp
```

Restart Codex and check its MCP settings, or run `codex mcp list`.
[Official Codex instructions](https://learn.chatgpt.com/docs/extend/mcp?surface=cli).

### Claude Code

```sh
claude mcp add --transport stdio --scope user slop -- npx --yes --package=https://slop.game/downloads/slop-game-mcp-0.2.0.tgz slop-mcp
```

Restart Claude Code and run `/mcp` to check Slop.
[Official Claude Code instructions](https://code.claude.com/docs/en/mcp).

### Cursor and other local MCP clients

Merge the Slop entry into `~/.cursor/mcp.json`, preserving your other servers,
then enable Slop in Cursor's MCP settings:

```json
{
  "mcpServers": {
    "slop": {
      "type": "stdio",
      "command": "npx",
      "args": [
        "--yes",
        "--package=https://slop.game/downloads/slop-game-mcp-0.2.0.tgz",
        "slop-mcp"
      ]
    }
  }
}
```

[Official Cursor instructions](https://cursor.com/docs/mcp). Other clients use
their own local MCP configuration with the same command and arguments. If a
desktop app cannot find `npx`, use its actual absolute executable path.

## Pair, send, play

1. Ask your agent: **“Call slop_pair and show me the QR code and pairing link.”**
2. Open **Slop → Build → Scan code** on your phone. Scan the computer's QR,
   review the named agent, and allow draft access. You can also open the exact
   pairing link on the website and approve it while signed in.
3. Ask the agent to check `slop_connection_status`, then call `slop_game_template` and build a small game around its unchanged
   `slop.js`. Send the complete bundle with `slop_send_draft`.
4. The draft appears in the same account's computer connection inbox on web and
   mobile. Select **Try on my phone** or **Playtest & publish** on the website.
   A validated, immutable private preview opens after your approval.
5. For another iteration, ask your agent to send the next revision. Review it
   separately. Disconnect the computer any time in Slop.

A QR is a pending request, not a connection. Delivery marked
`awaiting_confirmation` is waiting for you; it is not yet a playable preview.
Pairing challenges expire after ten minutes; approved connections last thirty
days unless revoked sooner. Publishing is a separate Slop action.

Available tools: `slop_pair`, `slop_connection_status`, `slop_game_template`,
`slop_send_draft`,
`slop_draft_status`, and `slop_disconnect`.

## Bundle contract

Keep `project_id` stable, increment integer `revision`, and use a new
`request_id` for each new revision. Reuse a request ID only for an identical
retry. Include `index.html`; use relative file paths. Bundles are self-contained
text: HTML, JavaScript, CSS, JSON, SVG, and TXT. Maximum 64 files, 512 KB per file,
and 2 MB total. Paid Store asset manifests, archives and binary uploads are not
supported by this adapter.

Source remains private. The service verifies your Slop session, reserves each
upload through the mobile app's owner-bound storage rules, and asks the existing
game-bundle authority to verify the exact manifest and mint an immutable
fifteen-minute preview. Agents receive only delivery status.

Each revision has a separate server-generated slug. Superseded work, expired
leases and revoked connections cannot finish as newly ready. A lost success
response can be reconciled through status and a fresh preview of the same
latest revision. An interrupted confirmation may need three minutes before retry.

Limits are ten active connections, twenty projects, sixty new revisions a day,
and twenty MB of retained source per account. Disconnecting removes future
bridge access; it preserves existing private games and does not retroactively
revoke independent, already issued fifteen-minute previews.

## Local development and operations

```sh
cd mcp
npm ci
npm test
npm run package
node cli.mjs
```

The adapter speaks MCP on standard input/output. An idle terminal is expected.
`SLOP_MCP_URL` can override the default deployed REST bridge
`https://api.slop.game/functions/v1/slop-mcp`; this is not a remote MCP URL.
`SLOP_MCP_CREDENTIALS` can select an isolated credential file. The default is
`~/.config/slop/mcp.json`, mode 0600. It stores only this adapter's limited grant
and pairing poll secret. Never add it to version control.

[Mobile/web HTTP contract](MOBILE-CONTRACT.md) and
[release verification](../docs/mcp-release-2026-09-16.md) describe deployment and
security checks. The Edge endpoint permits only owner routes from the exact
`https://slop.game` browser origin. It validates user JWTs itself; opaque local
agent tokens require gateway JWT verification to stay disabled.

Deploy only the `slop-mcp` Edge function. The existing MCP migration is already
live. **Do not bulk push migrations:** mobile and web migration histories differ.
Modern Supabase publishable/secret key maps take precedence over legacy keys;
server secrets stay in server-only API headers. Rollback first disables the
feature/endpoint, then revokes bridge entry points with [rollback.sql](rollback.sql).
Retain private source and idempotency records instead of dropping data.

Start game work with `slop_game_template`. It returns the native mobile runtime
and a working canvas example. Keep the returned slop.js unchanged; preserve
ready-after-first-frame, score, finished, restart, pause and touch integration.
The owner can playtest and record a cover/clip in the website draft inbox, then
explicitly submit the game through the same review process used by the app.
The coding agent has no publishing permission.

The returned `authorization_uri` starts on `api.slop.game` and redirects to the
fixed Slop account review page while keeping the short-lived challenge in the
fragment. `confirmation_uri` remains the QR URL accepted by the mobile scanner.
