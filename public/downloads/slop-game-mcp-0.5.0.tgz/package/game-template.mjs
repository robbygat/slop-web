import {readFile} from 'node:fs/promises';
const targets={
 mobile:'Build for a portrait phone viewport. Use touch-first controls, mobile safe areas, and never require a keyboard or mouse.',
 desktop:'Build for a responsive desktop viewport. Use keyboard and mouse controls and make the complete playfield fit without clipping.',
 'cross-platform':'Build one responsive game for phone and desktop. Provide equivalent touch controls and keyboard/mouse controls over one shared game state.',
};
const index=target=>'<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="slop-runtime" content="creator-v1"><meta name="slop-target" content="'+target+'"><title>Pocket Bounce</title></head><body><script src="slop.js"></script><script src="game.js"></script></body></html>';
const game=`const surface=Slop.create({background:'#faf3e8'}),ctx=surface.ctx;
let points=0,finished=false,announced=false,keyHeld=false;
Slop.onRestart(()=>{points=0;finished=false;keyHeld=false;Slop.score(0);});
Slop.loop(({time,width,height})=>{
 const keyDown=Slop.input.keys.has('Space')||Slop.input.keys.has('Enter');
 if((Slop.input.pressed||keyDown&&!keyHeld)&&!finished){points++;Slop.score(points);Slop.haptic('light');}
 keyHeld=keyDown;
 ctx.fillStyle='#faf3e8';ctx.fillRect(0,0,width,height);
 ctx.fillStyle='#302a3d';ctx.textAlign='center';ctx.font='bold 44px system-ui';ctx.fillText(points,width/2,height*.16);
 const y=height*.56-Math.abs(Math.sin(time*2.4))*36;
 ctx.fillStyle='#faaa47';ctx.beginPath();ctx.arc(width/2,y,48,0,Math.PI*2);ctx.fill();
 if(!points){ctx.fillStyle='#302a3d';ctx.font='bold 18px system-ui';ctx.fillText('Tap to bounce',width/2,height*.80);}
 if(!announced){announced=true;Slop.ready();}
 if(points>=10&&!finished){finished=true;Slop.finished(points);}
});`;
export async function gameTemplate({target_platform='cross-platform'}={}){if(!Object.hasOwn(targets,target_platform))throw new Error('Choose mobile, desktop, or cross-platform.');const instructions=`Start from these files. ${targets[target_platform]} Keep slop.js unchanged and include both meta tags. Call Slop.ready only after the first usable rendered frame, Slop.score during play, and Slop.finished once at real game over. Use Slop.onRestart, Slop.loop and Slop.input so native/web pause, resume, pointer, keyboard and touch controls work. Render changing gameplay on a canvas so Slop can capture a real moving GIF. Feed framing and HUD: the For You feed shows the 9:16 clip on phones up to ~9:19.5 and may trim the sides, so keep the player, targets and HUD inside the centered ~80% of the width and frame the camera/playfield slightly wide rather than tight. HUD = one big score or number near top-center plus at most 1-2 small icons (lives, a thin progress bar); no sentences, no \"SCORE:\"/\"LEVEL:\" labels, no stat panels in the corners. A control hint is at most 4 words and disappears on the first input; in-game callouts (combo, +10, PERFECT) are 1-2 words and fade quickly. Keep everything private until the owner explicitly submits for review. Sandbox rules: the game runs in an opaque-origin sandbox, so localStorage/sessionStorage/indexedDB throw and network requests are blocked; ship every file in the bundle (file names: letters, digits, _ or -, one html/js/css/json/svg/txt extension). The only external library is three.js r128 via Slop.three(); for 3D call Slop.create({renderer:'3d'}), render into surface.canvas with new THREE.WebGLRenderer({canvas:surface.canvas,preserveDrawingBuffer:true}) or the cover and GIF capture come back black. Slop captures the largest canvas, so keep one on-screen canvas that visibly moves even before input. Slop owns the start screen, pause and game-over card: do not draw a title, tap-to-start or play-again screen; at game over call Slop.finished once and keep animating until Slop.onRestart. slop.js calls preventDefault on pointerdown, so use pointer events, not mousedown or mouseup. On desktop, preventDefault wheel events so the page does not scroll, and give pointer lock a fallback. Slop.haptic is limited to 8 per second. Run slop_check_bundle before slop_send_draft.`;return {runtime:'creator-v1',target_platform,instructions,files:{'index.html':index(target_platform),'slop.js':await readFile(new URL('./runtime/creator-v1.js',import.meta.url),'utf8'),'slop-platform.json':JSON.stringify({target_platform}),'game.js':game}};}
